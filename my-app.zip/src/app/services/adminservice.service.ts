import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { FirstComponent } from '../first/first.component';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  constructor(private http: HttpClient, private login: FirstComponent) { }

  logincheck(username: any, password: any)
  {
    let postData = {username : username ,password :password};
  }
}
