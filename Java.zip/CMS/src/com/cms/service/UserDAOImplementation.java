package com.cms.service;

import com.cms.dao.UserDAO;

public class UserDAOImplementation implements UserDAO {

	@Override
	public void addFriend() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeFriend() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void courseEnroll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void login() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void courseCompletionNotification() {
		// TODO Auto-generated method stub
		
	}

}
