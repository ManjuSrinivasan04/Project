package com.cms.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cms.connectivity.JDBC;
import com.cms.dao.AdminDAO;
import com.cms.entity.Course;

public class AdminDAOImplementation implements AdminDAO {
	String name = "admin";
	String pwd = "admin";

	@Override
	public void login() {
		try {
			Statement stmt = JDBC.getConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from adminlogin");
			while (rs.next()) {
				if (name.equals(rs.getString("uname")) && (pwd.equals(rs.getString("pwd")))) {
					System.out.println("Logged In!!!!");
				}
				else
					System.out.println("Login failed!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void addCourse() {
		try {
//			PreparedStatement stmt = JDBC.getConnection().prepareStatement("INSERT INTO `course`(`courseName`, `courseID`, `startDate`, `endDate`) VALUES (?, ?, ?, ?)");
			Statement stmt = JDBC.getConnection().createStatement();
			int rs = stmt.executeUpdate("INSERT INTO `course`(`courseName`, `courseID`, `startDate`, `endDate`) VALUES ('Angular',2,\"2020-05-15\",'2020-05-22')");
//			stmt.setString(1,"");
//			stmt.setString(2,);
//			stmt.setString(3,'');
//			stmt.setString(4,'');
			if(rs==0)
				System.out.println("Not added");
			else
				System.out.println("added successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void deleteCourse() {
		// TODO Auto-generated method stub

	}

	@Override
	public void groupNotification() {
		// TODO Auto-generated method stub

	}

	@Override
	public void classWideNotification() {
		// TODO Auto-generated method stub

	}

	@Override
	public void courseStartNotification() {
		// TODO Auto-generated method stub

	}

	public static void main(String args[]) {
		AdminDAOImplementation ad = new AdminDAOImplementation();
		ad.addCourse();

	}

}
