package com.cms.repository;

public class CourseRepo {

}
