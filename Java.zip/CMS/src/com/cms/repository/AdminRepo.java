package com.cms.repository;

public class AdminRepo {

}
