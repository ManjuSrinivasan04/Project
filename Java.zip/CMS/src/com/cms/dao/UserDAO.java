package com.cms.dao;

public interface UserDAO {
	public void addFriend();
	public void removeFriend();
	public void courseEnroll();
	public void login();
	public void courseCompletionNotification();

}
