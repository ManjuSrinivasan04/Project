package com.cms.dao;

public interface AdminDAO {
	public void login();
	public void addCourse();
	public void deleteCourse();
	public void groupNotification();
	public void classWideNotification();
	public void courseStartNotification();

}
