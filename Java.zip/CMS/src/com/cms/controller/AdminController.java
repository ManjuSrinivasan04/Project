package com.cms.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("")
public class AdminController {
	@GET
	public void login()
	{
		
	}
	
	
	

}
